clear

java -Xms96m -Xmx96m -Djava.util.logging.config.file=Logging -jar dist/YManager.jar /var/www/html/data/db.json /var/www/html/data/ruleset.rs 

